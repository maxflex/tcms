angular.module('ngMap', []);
