require('./angular-locale_prg');
module.exports = 'ngLocale';
