require('./angular-locale_et');
module.exports = 'ngLocale';
