require('./angular-locale_ebu-ke');
module.exports = 'ngLocale';
