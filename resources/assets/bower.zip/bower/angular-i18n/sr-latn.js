require('./angular-locale_sr-latn');
module.exports = 'ngLocale';
