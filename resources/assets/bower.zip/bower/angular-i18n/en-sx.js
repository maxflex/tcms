require('./angular-locale_en-sx');
module.exports = 'ngLocale';
