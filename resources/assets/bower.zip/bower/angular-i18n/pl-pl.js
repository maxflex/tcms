require('./angular-locale_pl-pl');
module.exports = 'ngLocale';
