require('./angular-locale_tn-za');
module.exports = 'ngLocale';
