require('./angular-locale_fr-pf');
module.exports = 'ngLocale';
