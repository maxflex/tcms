require('./angular-locale_sr-cyrl-ba');
module.exports = 'ngLocale';
