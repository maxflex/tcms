require('./angular-locale_bm');
module.exports = 'ngLocale';
