require('./angular-locale_az-cyrl');
module.exports = 'ngLocale';
