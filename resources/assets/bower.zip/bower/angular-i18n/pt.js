require('./angular-locale_pt');
module.exports = 'ngLocale';
