require('./angular-locale_ks');
module.exports = 'ngLocale';
