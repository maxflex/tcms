require('./angular-locale_tg-cyrl');
module.exports = 'ngLocale';
