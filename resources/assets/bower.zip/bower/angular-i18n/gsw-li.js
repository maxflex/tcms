require('./angular-locale_gsw-li');
module.exports = 'ngLocale';
