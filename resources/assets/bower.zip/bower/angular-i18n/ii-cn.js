require('./angular-locale_ii-cn');
module.exports = 'ngLocale';
