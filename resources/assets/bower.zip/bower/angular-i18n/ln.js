require('./angular-locale_ln');
module.exports = 'ngLocale';
