require('./angular-locale_nyn');
module.exports = 'ngLocale';
