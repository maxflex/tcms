require('./angular-locale_en-lc');
module.exports = 'ngLocale';
