require('./angular-locale_iw');
module.exports = 'ngLocale';
