require('./angular-locale_gl');
module.exports = 'ngLocale';
