require('./angular-locale_en-sd');
module.exports = 'ngLocale';
