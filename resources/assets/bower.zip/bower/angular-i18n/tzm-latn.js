require('./angular-locale_tzm-latn');
module.exports = 'ngLocale';
