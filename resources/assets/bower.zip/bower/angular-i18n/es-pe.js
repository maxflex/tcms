require('./angular-locale_es-pe');
module.exports = 'ngLocale';
