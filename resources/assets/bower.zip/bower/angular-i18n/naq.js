require('./angular-locale_naq');
module.exports = 'ngLocale';
