require('./angular-locale_ha-ng');
module.exports = 'ngLocale';
