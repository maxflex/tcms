require('./angular-locale_ms-latn');
module.exports = 'ngLocale';
