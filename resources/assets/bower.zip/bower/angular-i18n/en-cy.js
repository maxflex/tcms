require('./angular-locale_en-cy');
module.exports = 'ngLocale';
