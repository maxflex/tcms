require('./angular-locale_kea');
module.exports = 'ngLocale';
