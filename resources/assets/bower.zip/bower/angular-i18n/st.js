require('./angular-locale_st');
module.exports = 'ngLocale';
