require('./angular-locale_ks-arab-in');
module.exports = 'ngLocale';
