require('./angular-locale_es-pa');
module.exports = 'ngLocale';
