require('./angular-locale_es-py');
module.exports = 'ngLocale';
