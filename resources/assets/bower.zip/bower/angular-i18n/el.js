require('./angular-locale_el');
module.exports = 'ngLocale';
