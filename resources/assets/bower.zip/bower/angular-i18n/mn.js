require('./angular-locale_mn');
module.exports = 'ngLocale';
