require('./angular-locale_mgh-mz');
module.exports = 'ngLocale';
