require('./angular-locale_fr-gf');
module.exports = 'ngLocale';
