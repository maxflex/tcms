require('./angular-locale_fr-ne');
module.exports = 'ngLocale';
