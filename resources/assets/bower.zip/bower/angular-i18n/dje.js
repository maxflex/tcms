require('./angular-locale_dje');
module.exports = 'ngLocale';
