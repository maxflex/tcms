require('./angular-locale_cu');
module.exports = 'ngLocale';
