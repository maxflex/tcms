require('./angular-locale_teo');
module.exports = 'ngLocale';
