require('./angular-locale_bs-latn-ba');
module.exports = 'ngLocale';
