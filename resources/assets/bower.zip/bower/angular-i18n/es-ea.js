require('./angular-locale_es-ea');
module.exports = 'ngLocale';
