require('./angular-locale_so-so');
module.exports = 'ngLocale';
