require('./angular-locale_el-cy');
module.exports = 'ngLocale';
