require('./angular-locale_nr');
module.exports = 'ngLocale';
