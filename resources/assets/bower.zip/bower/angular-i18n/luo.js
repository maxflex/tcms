require('./angular-locale_luo');
module.exports = 'ngLocale';
