require('./angular-locale_ar-sa');
module.exports = 'ngLocale';
