require('./angular-locale_ckb-iq');
module.exports = 'ngLocale';
