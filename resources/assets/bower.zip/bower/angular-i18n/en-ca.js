require('./angular-locale_en-ca');
module.exports = 'ngLocale';
