require('./angular-locale_ar-ae');
module.exports = 'ngLocale';
