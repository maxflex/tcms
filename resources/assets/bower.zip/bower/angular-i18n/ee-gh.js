require('./angular-locale_ee-gh');
module.exports = 'ngLocale';
