require('./angular-locale_uk-ua');
module.exports = 'ngLocale';
