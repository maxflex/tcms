require('./angular-locale_kk');
module.exports = 'ngLocale';
