require('./angular-locale_ln-cf');
module.exports = 'ngLocale';
