require('./angular-locale_ar-sd');
module.exports = 'ngLocale';
