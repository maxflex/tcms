require('./angular-locale_tk-tm');
module.exports = 'ngLocale';
