require('./angular-locale_yo-ng');
module.exports = 'ngLocale';
