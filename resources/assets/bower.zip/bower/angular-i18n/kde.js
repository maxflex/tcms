require('./angular-locale_kde');
module.exports = 'ngLocale';
