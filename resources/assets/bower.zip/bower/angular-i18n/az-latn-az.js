require('./angular-locale_az-latn-az');
module.exports = 'ngLocale';
