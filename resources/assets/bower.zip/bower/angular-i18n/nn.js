require('./angular-locale_nn');
module.exports = 'ngLocale';
