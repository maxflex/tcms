require('./angular-locale_fur-it');
module.exports = 'ngLocale';
