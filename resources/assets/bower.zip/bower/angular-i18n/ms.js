require('./angular-locale_ms');
module.exports = 'ngLocale';
