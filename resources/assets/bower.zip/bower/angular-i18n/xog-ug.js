require('./angular-locale_xog-ug');
module.exports = 'ngLocale';
