require('./angular-locale_hsb-de');
module.exports = 'ngLocale';
