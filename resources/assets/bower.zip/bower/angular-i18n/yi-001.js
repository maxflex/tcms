require('./angular-locale_yi-001');
module.exports = 'ngLocale';
