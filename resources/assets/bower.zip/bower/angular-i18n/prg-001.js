require('./angular-locale_prg-001');
module.exports = 'ngLocale';
