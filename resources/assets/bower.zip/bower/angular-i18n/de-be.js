require('./angular-locale_de-be');
module.exports = 'ngLocale';
