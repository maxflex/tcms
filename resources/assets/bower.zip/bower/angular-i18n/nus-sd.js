require('./angular-locale_nus-sd');
module.exports = 'ngLocale';
