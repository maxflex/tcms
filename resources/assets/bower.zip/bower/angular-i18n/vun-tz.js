require('./angular-locale_vun-tz');
module.exports = 'ngLocale';
