require('./angular-locale_ko');
module.exports = 'ngLocale';
