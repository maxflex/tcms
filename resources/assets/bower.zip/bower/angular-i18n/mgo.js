require('./angular-locale_mgo');
module.exports = 'ngLocale';
