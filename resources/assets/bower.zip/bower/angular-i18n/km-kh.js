require('./angular-locale_km-kh');
module.exports = 'ngLocale';
