require('./angular-locale_se-no');
module.exports = 'ngLocale';
