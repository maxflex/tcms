require('./angular-locale_ar-xb');
module.exports = 'ngLocale';
