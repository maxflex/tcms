require('./angular-locale_hr');
module.exports = 'ngLocale';
