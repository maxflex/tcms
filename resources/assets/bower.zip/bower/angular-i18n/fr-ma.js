require('./angular-locale_fr-ma');
module.exports = 'ngLocale';
