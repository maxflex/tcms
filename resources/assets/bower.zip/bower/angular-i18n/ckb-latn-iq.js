require('./angular-locale_ckb-latn-iq');
module.exports = 'ngLocale';
