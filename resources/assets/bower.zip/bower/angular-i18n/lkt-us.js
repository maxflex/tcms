require('./angular-locale_lkt-us');
module.exports = 'ngLocale';
