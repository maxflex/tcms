require('./angular-locale_ln-cg');
module.exports = 'ngLocale';
