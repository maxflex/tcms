require('./angular-locale_lv');
module.exports = 'ngLocale';
