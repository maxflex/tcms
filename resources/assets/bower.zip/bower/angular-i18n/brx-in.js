require('./angular-locale_brx-in');
module.exports = 'ngLocale';
