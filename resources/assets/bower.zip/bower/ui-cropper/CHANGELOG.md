1.x
- [FIXED] ColorTheif, Exif lib strict mode errors
- [REMOVED] 3rdparty exif lib from gulb build as its already included manyally via crop-exif.js
- [ADDED] `eslint` to the project