'use strict';

require('./source/js/init.js');
module.exports = 'uiCropper';
